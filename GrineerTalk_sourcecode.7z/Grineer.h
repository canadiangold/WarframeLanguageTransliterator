#pragma once
#include "ToUpper.h"
#include <chrono>
void cuss(string& str) {
	int x = rand() % 3;
	switch (x)
	{
	case 0:
		str.append("GHUTRE");
		break;
	case 1:
		str.append("RAPATOK");
		break;
	case 2:
		str.append("GRETESK");
		break;
	default:
		break;
	}
}

//TODO: case-sensitivity?
void ToGrineer(string& str) {
	srand(time(NULL));
	string clem = "GRINEER:";

	for (unsigned int i = 0; i < str.size(); i++) {
		if (str.at(i) == '\\') {
			if (str.at(i + 1) == 'C') {
				cuss(clem);
				i += 4;
			}
		}
		else if (str.at(i) == 'A' && str.at(i + 1) == 'N' && str.at(i + 2) == 'D' && !IsLetter(str.at(i + 3)) && !IsLetter(str.at(i - 1))) {
			clem.append("NA");
			i += 2;
		}
		else if (str.at(i) == 'B' && str.at(i + 1) == 'I' && str.at(i + 2) == 'T' && str.at(i + 3) == 'C' && str.at(i + 4) == 'H' && !IsLetter(str.at(i - 1))) {
			clem.append("GUTORA");
			i += 4;
		}
		else if (str.at(i) == 'B') {
			if (str.at(i + 1) == 'A') {
				clem.append("RA");
				i++;
			}
			else if (str.at(i + 1) == 'E') {
				clem.append("KE");
				i++;
			}
			else if (str.at(i + 1) == 'O') {
				clem.append("BRO");
				i++;
			}
			else {
				clem.push_back('B');
			}
		}
		else if (str.at(i) == 'C') {
			if (!IsLetter(str.at(i - 1)) && str.at(i + 1) == 'L' && str.at(i + 2) == 'E' && str.at(i + 3) == 'M' && !IsLetter(str.at(i + 4))) {
				clem.append("CLEM");
				i += 3;
			}
			else if (str.at(i + 1) == 'K') {
				clem.push_back('F');
				i++;
			}
			else if (str.at(i + 1) == 'L' && IsLetter(str.at(i + 2))) {
				clem.append("GR");
				i++;
			}
			else
				clem.push_back('K');
		}
		else if (str.at(i) == 'D')
			clem.push_back('R');
		else if (str.at(i) == 'E' && IsVowel(str.at(i - 1)))
			; //skip sub. maybe maybe not correct, but it looks cleaner
		else if (str.at(i) == 'F' && str.at(i + 1) == 'O' && str.at(i + 2) == 'U' && str.at(i + 3) == 'R' && !IsLetter(str.at(i - 1))) {
			clem.append("FORR");
			i += 3;
		}
		else if (str.at(i) == 'G') {
			if (str.at(i + 1) == 'H') {
				clem.push_back('R');
				i++;
			}
			else if (str.at(i + 1) == 'R' && str.at(i + 2) == 'I' && str.at(i + 3) == 'N' && str.at(i + 4) == 'E' && str.at(i + 5) == 'E' && str.at(i + 6) == 'R') {
				clem.append("GRINEER");
				i += 6;
			}
		}
		else if (str.at(i) == 'H')
			clem.push_back('R');
		else if (str.at(i) == 'I') {
			if (!IsConsonant(str.at(i - 1)))
				clem.push_back('H');
			clem.push_back('U');
		}
		else if (str.at(i) == 'L') {
			if (str.at(i + 1) == 'L') {
				clem.append("SS");
				i++;
			}
			else if (!IsConsonant(str.at(i - 1))) {
				clem.push_back('D');
			}
			else
				clem.push_back(str.at(i));
		}
		else if (str.at(i) == 'M' && str.at(i + 1) == 'Y' && !IsLetter(str.at(i + 2)) && !IsLetter(str.at(i - 1))) {
			clem.append("TU");
			i++;
		}
		else if (str.at(i) == 'O' && str.at(i + 1) == 'N' && str.at(i + 2) == 'E' && !IsLetter(str.at(i - 1))) {
			clem.append("UK");
			i += 2;
		}
		else if (str.at(i) == 'O' && str.at(i + 1) == 'U' && IsLetter(str.at(i - 1))) {
			//this one isn't very correct but i like it
			clem.append("OVO");
			i++;
		}
		else if (str.at(i) == 'P' && !IsConsonant(str.at(i - 1)) && !IsConsonant(str.at(i + 1))) {
			clem.push_back('G');
		}
		else if (str.at(i) == 'Q') {
			clem.push_back('K');
		}
		else if (str.at(i) == 'R' && !IsConsonant(str.at(i - 1)) && IsVowel(str.at(i + 1))) {
			clem.append("GR");
		}
		else if (str.at(i) == 'S' && str.at(i + 1) == 'E' && str.at(i + 2) == 'V' && str.at(i + 3) == 'E' && str.at(i + 4) == 'N' && !IsLetter(str.at(i - 1))) {
			clem.append("SEVENK");
			i += 4;
		}
		else if (str.at(i) == 'S' && str.at(i + 1) == 'T') {
			clem.append("TR");
			i++;
		}
		else if (str.at(i) == 'T' && str.at(i + 1) == 'H' && str.at(i + 2) == 'R' && str.at(i + 3) == 'E' && str.at(i + 4) == 'E' && !IsLetter(str.at(i - 1))) {
			clem.append("CHEE");
			i += 4;
		}
		else if (str.at(i) == 'T' && str.at(i + 1) == 'H') {
			clem.append("KL");
			i++;
		}
		else if (str.at(i) == 'T' && str.at(i + 1) == 'W' && str.at(i + 2) == 'O' && !IsLetter(str.at(i - 1))) {
			clem.append("TOK");
			i += 2;
		}
		else if (str.at(i) == 'U' && IsConsonant(str.at(i - 1)) && IsConsonant(str.at(i + 1))) {
			//also not very correct but i also like it. plus it makes "scum" translate correctly
			clem.append("OO");
		}
		else if (str.at(i) == 'W') {
			if (str.at(i + 1) == 'H' && IsLetter(str.at(i + 2))) {
				clem.append("GR");
				i++;
			}
			else
				clem.push_back('R');
		}
		else if (str.at(i) == 'Y' && str.at(i + 1) == 'O' && str.at(i + 2) == 'U' && !IsLetter(str.at(i + 3)) && !IsLetter(str.at(i - 1))) {
			clem.append("GAR");
			i += 2;
		}
		else
			clem.push_back(str.at(i)); //NO SUBSTITUTION
	}

	cout << clem << endl;
}
