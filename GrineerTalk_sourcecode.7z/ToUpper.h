#pragma once
#include <string>
#include <iostream>
using namespace std;

void ToUpper(string& str) {
	for (unsigned int i = 0; i < str.size(); i++) {
		str.at(i) = toupper(str.at(i));
	}
}

bool IsConsonant(char c) {
	c = toupper(c);
	if (c == 'B' || c == 'C' || c == 'D' || c == 'F' || c == 'G' || c == 'H' || c == 'J' || c == 'K' || c == 'L' || c == 'M' || c == 'N' || c == 'P' || c == 'Q' || c == 'R' || c == 'S' || c == 'T' || c == 'V' || c == 'X' || c == 'W' || c == 'Z')
		return true;
	else
		return false;
}

bool IsVowel(char c) {
	c = toupper(c);
	if (c == 'A' || c == 'E' || c == 'I' || c == 'O' || c == 'U' || c == 'Y')
		return true;
	else
		return false;
}

bool IsLetter(char c) {
	if (IsConsonant(c) || IsVowel(c))
		return true;
	else
		return false;
}

void TF(bool x) {	//mainly for debugging
	if (x)
		cout << "TRUE\n";
	else
		cout << "FALSE\n";
}