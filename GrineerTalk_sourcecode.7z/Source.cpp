/***************************************************************************
/ Author: https://forums.warframe.com/profile/1281553-canadiangold96/		/
/ You are free to use this as you wish: modify it, share it, whatever, just	/
/	don't claim it's all yours.												/
/ I wrote this for fun as a fanfic author. I want it to remain a simple lil	/
/	desktop-based utility.													/
/***************************************************************************/
#include "Grineer.h"

int main() {
	string clem, str;
	cout << "Type some stuff, then press Enter to convert it to Grineer.\n";
	cout << "Consider this a guideline rather than a direct translation.\n";
	//cout << "Press CTRL+C without highlighting text to end the program.\n"; //bro just click the X
	cout << "Input is not case sensitive. The Grineer output will always be all-caps.\n";
	cout << "Type \"\\cuss\" to insert a random Grineer swear word.\n";
	cout << "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~";
	
	while(true){
		clem = " ";
		cout << endl << "ENGLISH: ";
		getline(cin,str);
		ToUpper(str);

		clem.append(str);
		clem.append(" ");
		ToGrineer(clem);
	}
	
	return 0;
}