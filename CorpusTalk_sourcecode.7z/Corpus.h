#pragma once
#include "ToUpper.h"

void ToCorpus(string str) {
	for (unsigned int i = 0; i < str.size(); i++) {
		if (str.at(i) == 'B')
			str.at(i) = 'T';
		else if (str.at(i) == 'C')
			str.at(i) = 'Y';
		else if (str.at(i) == 'D')
			str.at(i) = 'P';
		else if (str.at(i) == 'F')
			str.at(i) = 'T';
		else if (str.at(i) == 'G')
			str.at(i) = 'J';
		else if (str.at(i) == 'H')
			str.at(i) = 'K';
		else if (str.at(i) == 'J')
			str.at(i) = 'T';
		else if (str.at(i) == 'L')
			str.at(i) = 'P';
		else if (str.at(i) == 'M')
			str.at(i) = 'S';
		else if (str.at(i) == 'N')
			str.at(i) = 'T';
		else if (str.at(i) == 'P')
			str.at(i) = 'K';
		else if (str.at(i) == 'Q')
			str.at(i) = 'R';
		else if (str.at(i) == 'R')
			str.at(i) = 'T';
		else if (str.at(i) == 'S')
			str.at(i) = 'Y';
		else if (str.at(i) == 'T')
			str.at(i) = 'P';
		else if (str.at(i) == 'V')
			str.at(i) = 'T';
		else if (str.at(i) == 'W')
			str.at(i) = 'J';
		else if (str.at(i) == 'X')
			str.at(i) = 'K';
		else if (str.at(i) == 'Z')
			str.at(i) = 'B';
	}
		cout << "CORPUS:  " << str << endl;
	
}