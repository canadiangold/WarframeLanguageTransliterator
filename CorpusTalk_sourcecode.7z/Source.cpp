#include "Corpus.h"

int main() {
	string str;
	cout << "Type some stuff, then press Enter to convert it to Corpus.\n";
	cout << "Press CTRL+C at any time to end the program.\n";
	cout << "Highlight text and CTRL+C to copy.\n";
	cout << "*	*	*	*	*	*	*";

	while (true) {
		cout << endl << "ENGLISH: ";
		getline(cin, str);
		ToUpper(str);

		ToCorpus(str);
	}
	return 0;
}